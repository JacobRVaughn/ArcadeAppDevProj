import pygame
import math
import random
import sys
import json

pygame.init()
pygame.mixer.init()

# --- Constants ---
SCREEN_W, SCREEN_H = 1000, 700
GRID_COLS, GRID_ROWS = 20, 14
CELL = SCREEN_W // GRID_COLS  # 50px
FPS = 60

# Colors
SKY       = (135, 206, 235)
GRASS     = (106, 168, 79)
PATH_CLR  = (210, 180, 140)
DARK_PATH = (180, 150, 110)
WHITE     = (255, 255, 255)
BLACK     = (10, 10, 10)
GOLD      = (255, 215, 0)
RED       = (220, 50, 50)
GREEN     = (50, 200, 80)
BLUE      = (50, 120, 220)
PURPLE    = (160, 32, 240)
ORANGE    = (255, 140, 0)
PINK      = (255, 105, 180)
TEAL      = (0, 180, 160)
DARK_GREEN= (34, 100, 34)
UI_BG     = (30, 30, 50)
UI_PANEL  = (45, 45, 70)
HIGHLIGHT = (255, 240, 100)

# Path definition (col, row) waypoints
WAYPOINTS = [
    (0, 3), (4, 3), (4, 7), (8, 7), (8, 2),
    (13, 2), (13, 10), (17, 10), (17, 6), (19, 6)
]

# Tower definitions
TOWER_TYPES = {
    "math":    {"name": "Math Wizard",   "color": BLUE,   "range": 120, "fire_rate": 90,  "damage": 1, "cost": 50,  "emoji": "🔢"},
    "letters": {"name": "Word Fairy",    "color": PINK,   "range": 100, "fire_rate": 75,  "damage": 1, "cost": 40,  "emoji": "📚"},
    "science": {"name": "Science Bot",   "color": TEAL,   "range": 140, "fire_rate": 110, "damage": 2, "cost": 75,  "emoji": "🔬"},
    "music":   {"name": "Music Note",    "color": PURPLE, "range": 90,  "fire_rate": 60,  "damage": 1, "cost": 35,  "emoji": "🎵"},
}

# Questions per tower type
QUESTIONS = {
    "math": [
        ("2 + 3 = ?",   "5"),
        ("4 × 2 = ?",   "8"),
        ("10 - 4 = ?",  "6"),
        ("3 + 7 = ?",   "10"),
        ("5 × 3 = ?",   "15"),
        ("12 ÷ 4 = ?",  "3"),
        ("6 + 8 = ?",   "14"),
        ("9 - 5 = ?",   "4"),
        ("4 + 4 = ?",   "8"),
        ("7 × 2 = ?",   "14"),
    ],
    "letters": [
        ("First letter of 'Apple'?",  "A"),
        ("What rhymes with 'cat'?",   "BAT"),
        ("'Dog' starts with?",        "D"),
        ("How many vowels in 'RAIN'?","2"),
        ("'Sun' ends with?",          "N"),
        ("Vowel in 'PIG'?",           "I"),
        ("'Blue' starts with?",       "B"),
        ("How many letters in 'CAT'?","3"),
        ("'Fish' ends with?",         "H"),
        ("Opposite of 'big'?",        "SMALL"),
    ],
    "science": [
        ("How many legs on a spider?", "8"),
        ("What do plants need to grow?","SUN"),
        ("What planet do we live on?",  "EARTH"),
        ("Water freezes at what temp?", "0"),
        ("How many seasons in a year?", "4"),
        ("What do fish breathe with?",  "GILLS"),
        ("Biggest planet in our system?","JUPITER"),
        ("What gives us light at night?","MOON"),
        ("Sound travels in what form?",  "WAVES"),
        ("How many moons does Earth have?","1"),
    ],
    "music": [
        ("How many notes in a scale?",  "7"),
        ("What is a group of musicians?","BAND"),
        ("Loud in music means?",        "FORTE"),
        ("How many strings on guitar?", "6"),
        ("Do-Re-Mi is which scale?",    "C"),
        ("Opposite of loud?",           "SOFT"),
        ("What keeps the beat?",        "DRUMS"),
        ("How many beats in 4/4 time?", "4"),
        ("A single musical sound?",     "NOTE"),
        ("Fast tempo means?",           "QUICK"),
    ],
}

# --- Utility ---
def cell_to_px(col, row):
    return col * CELL + CELL // 2, row * CELL + CELL // 2

def build_path_cells(waypoints):
    cells = []
    for i in range(len(waypoints) - 1):
        c0, r0 = waypoints[i]
        c1, r1 = waypoints[i+1]
        dc = 1 if c1 > c0 else (-1 if c1 < c0 else 0)
        dr = 1 if r1 > r0 else (-1 if r1 < r0 else 0)
        c, r = c0, r0
        while (c, r) != (c1, r1):
            if (c, r) not in cells:
                cells.append((c, r))
            c += dc
            r += dr
    cells.append((c1, r1))
    return cells

PATH_CELLS = build_path_cells(WAYPOINTS)
PATH_SET   = set(PATH_CELLS)

# Build pixel waypoints
PX_WAYPOINTS = [cell_to_px(c, r) for c, r in WAYPOINTS]

# --- Enemy ---
ENEMY_WAVES = [
    # wave: list of (type, count, interval)
    [("bug",    5, 90)],
    [("bug",    8, 75), ("snail", 3, 120)],
    [("bug",   10, 60), ("snail", 5, 90)],
    [("bug",   12, 50), ("snail", 6, 80), ("beast", 2, 150)],
    [("bug",   15, 45), ("snail", 8, 70), ("beast", 4, 120)],
]

ENEMY_DEFS = {
    "bug":   {"hp": 3,  "speed": 1.4, "reward": 5,  "color": RED,    "size": 12, "label": "🐛"},
    "snail": {"hp": 6,  "speed": 0.8, "reward": 10, "color": ORANGE, "size": 15, "label": "🐌"},
    "beast": {"hp": 15, "speed": 0.9, "reward": 25, "color": PURPLE, "size": 18, "label": "👾"},
}

class Enemy:
    def __init__(self, etype, offset=0):
        d = ENEMY_DEFS[etype]
        self.etype   = etype
        self.hp      = d["hp"]
        self.max_hp  = d["hp"]
        self.speed   = d["speed"]
        self.reward  = d["reward"]
        self.color   = d["color"]
        self.size    = d["size"]
        self.label   = d["label"]
        self.wp_idx  = 0
        self.x, self.y = PX_WAYPOINTS[0]
        self.x      -= offset
        self.alive   = True
        self.reached = False
        self.dist_traveled = 0.0

    def move(self):
        if self.wp_idx >= len(PX_WAYPOINTS) - 1:
            self.reached = True
            return
        tx, ty = PX_WAYPOINTS[self.wp_idx + 1]
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)
        if dist < self.speed:
            self.x, self.y = tx, ty
            self.wp_idx += 1
            self.dist_traveled += dist
        else:
            self.x += dx / dist * self.speed
            self.y += dy / dist * self.speed
            self.dist_traveled += self.speed

    def draw(self, surf):
        # Shadow
        pygame.draw.ellipse(surf, (0, 0, 0, 80),
                            (int(self.x) - self.size, int(self.y) + self.size - 4,
                             self.size * 2, 8))
        # Body
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.size)
        pygame.draw.circle(surf, WHITE, (int(self.x), int(self.y)), self.size, 2)

        # HP bar
        bar_w = self.size * 2
        frac  = self.hp / self.max_hp
        bx    = int(self.x) - self.size
        by    = int(self.y) - self.size - 8
        pygame.draw.rect(surf, (80, 0, 0), (bx, by, bar_w, 5))
        pygame.draw.rect(surf, GREEN, (bx, by, int(bar_w * frac), 5))

        # Label font
        fnt = pygame.font.SysFont("segoeui", 14, bold=True)
        txt = fnt.render(self.label, True, WHITE)
        surf.blit(txt, (int(self.x) - txt.get_width()//2,
                        int(self.y) - txt.get_height()//2))

# --- Projectile ---
class Projectile:
    def __init__(self, sx, sy, target, damage, color):
        self.x, self.y = sx, sy
        self.target = target
        self.damage = damage
        self.color  = color
        self.speed  = 5
        self.alive  = True
        self.trail  = []

    def update(self):
        if not self.target.alive:
            self.alive = False
            return
        dx = self.target.x - self.x
        dy = self.target.y - self.y
        dist = math.hypot(dx, dy)
        if dist < self.speed + 5:
            self.target.hp -= self.damage
            if self.target.hp <= 0:
                self.target.alive = False
            self.alive = False
        else:
            self.trail.append((self.x, self.y))
            if len(self.trail) > 8:
                self.trail.pop(0)
            self.x += dx / dist * self.speed
            self.y += dy / dist * self.speed

    def draw(self, surf):
        for i, (tx, ty) in enumerate(self.trail):
            alpha = int(255 * i / len(self.trail)) if self.trail else 0
            r = max(2, int(6 * i / max(len(self.trail), 1)))
            c = tuple(min(255, int(v * (0.5 + 0.5 * i / max(len(self.trail),1)))) for v in self.color)
            pygame.draw.circle(surf, c, (int(tx), int(ty)), r)
        pygame.draw.circle(surf, WHITE, (int(self.x), int(self.y)), 6)
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), 4)

# --- Tower ---
class Tower:
    def __init__(self, col, row, ttype):
        self.col, self.row = col, row
        self.x, self.y = cell_to_px(col, row)
        self.ttype   = ttype
        td           = TOWER_TYPES[ttype]
        self.name    = td["name"]
        self.color   = td["color"]
        self.range   = td["range"]
        self.fire_rate = td["fire_rate"]
        self.damage  = td["damage"]
        self.cooldown = 0
        self.level   = 1
        self.kills   = 0
        self.angle   = 0
        self.anim    = 0

    def upgrade(self):
        if self.level < 3:
            self.level  += 1
            self.damage += 1
            self.range  = int(self.range * 1.2)
            self.fire_rate = max(20, self.fire_rate - 15)

    def try_shoot(self, enemies, projectiles):
        if self.cooldown > 0:
            self.cooldown -= 1
            return
        best   = None
        best_d = 0
        for e in enemies:
            if not e.alive: continue
            dist = math.hypot(e.x - self.x, e.y - self.y)
            if dist <= self.range and e.dist_traveled > best_d:
                best   = e
                best_d = e.dist_traveled
        if best:
            self.cooldown = self.fire_rate
            self.angle = math.degrees(math.atan2(best.y - self.y, best.x - self.x))
            self.anim  = 10
            projectiles.append(Projectile(self.x, self.y, best, self.damage, self.color))

    def draw(self, surf, selected=False):
        bx, by = self.x - CELL//2, self.y - CELL//2
        # Base platform
        pygame.draw.rect(surf, (60, 60, 80), (bx+4, by+4, CELL-8, CELL-8), border_radius=8)
        pygame.draw.rect(surf, self.color, (bx+6, by+6, CELL-12, CELL-12), border_radius=6)

        # Level stars
        for i in range(self.level):
            sx = bx + 8 + i * 10
            pygame.draw.circle(surf, GOLD, (sx, by + 8), 4)

        # Cannon barrel
        rad = math.radians(self.angle)
        ex  = self.x + math.cos(rad) * 18
        ey  = self.y + math.sin(rad) * 18
        pygame.draw.line(surf, BLACK, (self.x, self.y), (int(ex), int(ey)), 5)
        pygame.draw.line(surf, WHITE, (self.x, self.y), (int(ex), int(ey)), 3)

        # Tower body circle
        r = 14 + (self.anim // 3)
        if self.anim > 0: self.anim -= 1
        pygame.draw.circle(surf, BLACK, (self.x, self.y), r + 2)
        pygame.draw.circle(surf, self.color, (self.x, self.y), r)

        # Icon
        fnt = pygame.font.SysFont("segoeui", 18)
        em  = TOWER_TYPES[self.ttype]["emoji"]
        txt = fnt.render(em, True, WHITE)
        surf.blit(txt, (self.x - txt.get_width()//2, self.y - txt.get_height()//2))

        if selected:
            pygame.draw.circle(surf, HIGHLIGHT, (self.x, self.y), self.range, 2)
            pygame.draw.circle(surf, HIGHLIGHT, (self.x, self.y), r + 4, 3)

# --- Floating Text ---
class FloatText:
    def __init__(self, x, y, text, color):
        self.x, self.y = x, y
        self.text  = text
        self.color = color
        self.life  = 60
        self.vy    = -1.5

    def update(self):
        self.y   += self.vy
        self.life -= 1

    def draw(self, surf):
        alpha = min(255, self.life * 5)
        fnt   = pygame.font.SysFont("comicsansms", 18, bold=True)
        txt   = fnt.render(self.text, True, self.color)
        surf.blit(txt, (int(self.x) - txt.get_width()//2, int(self.y)))

# --- Quiz Popup ---
class QuizPopup:
    def __init__(self, ttype, on_correct, on_wrong):
        q_list = QUESTIONS[ttype]
        self.q, self.a = random.choice(q_list)
        self.ttype      = ttype
        self.on_correct = on_correct
        self.on_wrong   = on_wrong
        self.input      = ""
        self.result     = None  # None / True / False
        self.timer      = 0
        self.active     = True
        self.shake      = 0

    def handle_event(self, event):
        if not self.active: return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                self._submit()
            elif event.key == pygame.K_BACKSPACE:
                self.input = self.input[:-1]
            else:
                ch = event.unicode.upper()
                if ch in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ ":
                    self.input += ch
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            # submit button area
            if 430 <= mx <= 570 and 430 <= my <= 460:
                self._submit()

    def _submit(self):
        if self.input.strip() == self.a:
            self.result = True
            self.on_correct()
        else:
            self.result = False
            self.shake  = 10
            self.on_wrong()
        self.timer = 90

    def update(self):
        if self.result is not None:
            self.timer -= 1
            if self.timer <= 0:
                self.active = False
        if self.shake > 0:
            self.shake -= 1

    def draw(self, surf):
        # Dim overlay
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        surf.blit(overlay, (0, 0))

        off = random.randint(-2, 2) if self.shake > 0 else 0
        bx, by = 250 + off, 200
        bw, bh = 500, 300
        color = TOWER_TYPES[self.ttype]["color"]

        # Card
        pygame.draw.rect(surf, UI_PANEL, (bx, by, bw, bh), border_radius=20)
        pygame.draw.rect(surf, color, (bx, by, bw, bh), 4, border_radius=20)

        # Header
        pygame.draw.rect(surf, color, (bx, by, bw, 60), border_radius=20)
        hfnt = pygame.font.SysFont("comicsansms", 22, bold=True)
        htxt = hfnt.render(f"{TOWER_TYPES[self.ttype]['emoji']}  Answer to place tower!", True, WHITE)
        surf.blit(htxt, (bx + bw//2 - htxt.get_width()//2, by + 15))

        # Question
        qfnt = pygame.font.SysFont("comicsansms", 26, bold=True)
        qtxt = qfnt.render(self.q, True, WHITE)
        surf.blit(qtxt, (bx + bw//2 - qtxt.get_width()//2, by + 90))

        # Input box
        ifnt = pygame.font.SysFont("comicsansms", 30, bold=True)
        ibox_color = GREEN if self.result == True else (RED if self.result == False else HIGHLIGHT)
        pygame.draw.rect(surf, ibox_color, (bx+100, by+150, bw-200, 50), border_radius=10)
        pygame.draw.rect(surf, BLACK, (bx+100, by+150, bw-200, 50), 2, border_radius=10)
        disp = self.input + ("|" if self.result is None and (pygame.time.get_ticks()//500)%2==0 else "")
        itxt = ifnt.render(disp, True, BLACK)
        surf.blit(itxt, (bx+100 + (bw-200)//2 - itxt.get_width()//2, by+158))

        # Result message
        if self.result == True:
            rtxt = hfnt.render("🌟 Correct! Tower placed!", True, GOLD)
            surf.blit(rtxt, (bx + bw//2 - rtxt.get_width()//2, by+220))
        elif self.result == False:
            rtxt = hfnt.render(f"❌ Answer was: {self.a}", True, RED)
            surf.blit(rtxt, (bx + bw//2 - rtxt.get_width()//2, by+220))
        else:
            # Submit hint
            sfnt = pygame.font.SysFont("comicsansms", 16)
            stxt = sfnt.render("Type your answer and press ENTER", True, (180, 180, 200))
            surf.blit(stxt, (bx + bw//2 - stxt.get_width()//2, by+260))

# --- Main Game ---
class Game:
    def __init__(self):
        self.screen  = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption("🌟 Knowledge Kingdom – Tower Defense")
        self.clock   = pygame.time.Clock()

        self.reset()

    def reset(self):
        self.coins    = 150
        self.lives    = 20
        self.score    = 0
        self.wave_num = 0
        self.wave_active = False
        self.spawn_queue = []   # (etype, delay_timer)
        self.spawn_timer  = 0

        self.towers      = []
        self.enemies     = []
        self.projectiles = []
        self.float_texts = []
        self.quiz_popup  = None

        self.selected_type  = "math"
        self.placing        = False
        self.selected_tower = None
        self.hover_cell     = None

        self.state   = "play"  # play / gameover / win
        self.paused  = False

        self.bg_surf = self._build_bg()

    def _build_bg(self):
        surf = pygame.Surface((SCREEN_W, SCREEN_H))
        # Sky
        surf.fill(SKY)
        # Clouds
        for cx, cy, cr in [(100,40,40),(200,60,30),(400,30,50),(700,50,35),(850,40,45)]:
            pygame.draw.ellipse(surf, WHITE, (cx-cr, cy-cr//2, cr*2, cr))
            pygame.draw.ellipse(surf, WHITE, (cx-cr//2, cy-cr*0.8, cr, cr))
        # Grass tiles
        for col in range(GRID_COLS):
            for row in range(GRID_ROWS):
                if (col, row) not in PATH_SET:
                    x, y = col*CELL, row*CELL
                    c = GRASS if (col+row)%2==0 else (95,155,65)
                    pygame.draw.rect(surf, c, (x, y, CELL, CELL))
                    # Random small flowers
                    if random.random() < 0.15:
                        fx, fy = x + random.randint(5, CELL-5), y + random.randint(5, CELL-5)
                        fc = random.choice([PINK, GOLD, WHITE, (200,100,200)])
                        pygame.draw.circle(surf, fc, (fx, fy), 3)
        # Path
        for col, row in PATH_CELLS:
            x, y = col*CELL, row*CELL
            pygame.draw.rect(surf, PATH_CLR, (x, y, CELL, CELL))
            pygame.draw.rect(surf, DARK_PATH, (x, y, CELL, CELL), 1)
        # Trees at corners
        for tx, ty in [(15,15),(15,625),(SCREEN_W-15,15),(SCREEN_W-15,SCREEN_H-70)]:
            pygame.draw.rect(surf, (100,60,20), (tx-4, ty, 8, 20))
            pygame.draw.circle(surf, DARK_GREEN, (tx, ty), 15)
            pygame.draw.circle(surf, GREEN, (tx, ty-4), 12)
        return surf

    def start_wave(self):
        if self.wave_num >= len(ENEMY_WAVES):
            return
        self.wave_active = True
        wave = ENEMY_WAVES[self.wave_num]
        queue = []
        for etype, count, interval in wave:
            for i in range(count):
                queue.append((etype, i * interval))
        queue.sort(key=lambda x: x[1])
        self.spawn_queue = queue
        self.spawn_timer  = 0

    def update(self):
        if self.state != "play" or self.paused or self.quiz_popup:
            if self.quiz_popup:
                self.quiz_popup.update()
                if not self.quiz_popup.active:
                    self.quiz_popup = None
            return

        # Spawn enemies
        if self.wave_active and self.spawn_queue:
            self.spawn_timer += 1
            while self.spawn_queue and self.spawn_timer >= self.spawn_queue[0][1]:
                etype, _ = self.spawn_queue.pop(0)
                self.enemies.append(Enemy(etype))

        # Check wave done
        if self.wave_active and not self.spawn_queue and all(not e.alive or e.reached for e in self.enemies):
            alive = [e for e in self.enemies if e.alive and not e.reached]
            if not alive:
                self.wave_active = False
                self.wave_num   += 1
                self.coins      += 30  # wave bonus
                self.float_texts.append(FloatText(SCREEN_W//2, 300, "+30 Wave Bonus!", GOLD))
                if self.wave_num >= len(ENEMY_WAVES):
                    self.state = "win"

        # Move enemies
        for e in self.enemies:
            if e.alive and not e.reached:
                e.move()
            if e.reached and e.alive:
                e.alive = False
                self.lives -= 1
                self.float_texts.append(FloatText(SCREEN_W//2, 200, "-1 Life!", RED))
                if self.lives <= 0:
                    self.state = "gameover"

        # Towers shoot
        alive_enemies = [e for e in self.enemies if e.alive and not e.reached]
        for t in self.towers:
            t.try_shoot(alive_enemies, self.projectiles)

        # Projectiles
        for p in self.projectiles:
            p.update()
            if not p.alive:
                # Check if killed
                pass

        # Collect coins for kills
        for e in self.enemies:
            if not e.alive and e.reward > 0:
                self.coins += e.reward
                self.score += e.reward
                self.float_texts.append(FloatText(e.x, e.y - 20, f"+{e.reward}🪙", GOLD))
                e.reward = 0  # prevent double-collect

        # Float texts
        for ft in self.float_texts:
            ft.update()
        self.float_texts = [ft for ft in self.float_texts if ft.life > 0]

        # Cleanup
        self.enemies     = [e for e in self.enemies if e.alive or e.reached]
        self.enemies     = [e for e in self.enemies if not (not e.alive and e.reward == 0 and e.reached)]
        self.enemies     = [e for e in self.enemies if e.alive]
        self.projectiles = [p for p in self.projectiles if p.alive]

    def draw(self):
        self.screen.blit(self.bg_surf, (0, 0))

        # Range preview
        if self.placing and self.hover_cell:
            hc, hr = self.hover_cell
            if (hc, hr) not in PATH_SET and not self._tower_at(hc, hr):
                td = TOWER_TYPES[self.selected_type]
                hx, hy = cell_to_px(hc, hr)
                s = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
                pygame.draw.circle(s, (*td["color"], 40), (hx, hy), td["range"])
                pygame.draw.circle(s, (*td["color"], 100), (hx, hy), td["range"], 2)
                self.screen.blit(s, (0, 0))
                # Ghost tower
                r = pygame.Rect(hc*CELL+6, hr*CELL+6, CELL-12, CELL-12)
                pygame.draw.rect(self.screen, (*td["color"], 150), r, border_radius=6)
            else:
                # Red X for invalid
                if self.hover_cell:
                    hc2, hr2 = self.hover_cell
                    r = pygame.Rect(hc2*CELL, hr2*CELL, CELL, CELL)
                    s = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
                    s.fill((255, 0, 0, 80))
                    self.screen.blit(s, (hc2*CELL, hr2*CELL))

        # Selected tower range
        if self.selected_tower:
            s = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.selected_tower.color, 30),
                               (self.selected_tower.x, self.selected_tower.y),
                               self.selected_tower.range)
            self.screen.blit(s, (0, 0))

        # Towers
        for t in self.towers:
            t.draw(self.screen, selected=(t == self.selected_tower))

        # Enemies
        for e in self.enemies:
            e.draw(self.screen)

        # Projectiles
        for p in self.projectiles:
            p.draw(self.screen)

        # Float texts
        for ft in self.float_texts:
            ft.draw(self.screen)

        # UI
        self._draw_ui()

        # Quiz
        if self.quiz_popup:
            self.quiz_popup.draw(self.screen)

        # Overlays
        if self.state == "gameover":
            self._draw_overlay("💀 Game Over!", RED, "Press R to try again")
        elif self.state == "win":
            self._draw_overlay("🌟 You Win! Knowledge Wins!", GOLD, "Press R to play again")

        pygame.display.flip()

    def _draw_ui(self):
        # Top bar
        pygame.draw.rect(self.screen, UI_BG, (0, SCREEN_H - 120, SCREEN_W, 120))
        pygame.draw.line(self.screen, GOLD, (0, SCREEN_H - 120), (SCREEN_W, SCREEN_H - 120), 2)

        fnt   = pygame.font.SysFont("comicsansms", 18, bold=True)
        sfnt  = pygame.font.SysFont("comicsansms", 14)

        # Stats
        stats = [
            (f"🪙 {self.coins}", GOLD,  15),
            (f"❤️  {self.lives}",  RED,   120),
            (f"⭐ {self.score}",  WHITE, 220),
            (f"🌊 Wave {self.wave_num+1}/{len(ENEMY_WAVES)}", TEAL, 330),
        ]
        for txt, col, x in stats:
            t = fnt.render(txt, True, col)
            self.screen.blit(t, (x, SCREEN_H - 115))

        # Tower buttons
        bw, bh = 105, 90
        for i, (ttype, td) in enumerate(TOWER_TYPES.items()):
            bx = 490 + i * (bw + 8)
            by = SCREEN_H - 112
            selected = (ttype == self.selected_type and self.placing)
            col = td["color"]
            border = HIGHLIGHT if selected else (80, 80, 100)
            pygame.draw.rect(self.screen, UI_PANEL, (bx, by, bw, bh), border_radius=10)
            pygame.draw.rect(self.screen, border, (bx, by, bw, bh), 3, border_radius=10)
            if selected:
                glow = pygame.Surface((bw, bh), pygame.SRCALPHA)
                glow.fill((*col, 60))
                self.screen.blit(glow, (bx, by))

            # Icon + name
            efnt = pygame.font.SysFont("segoeui", 28)
            et   = efnt.render(td["emoji"], True, WHITE)
            self.screen.blit(et, (bx + bw//2 - et.get_width()//2, by + 5))
            nt   = sfnt.render(td["name"], True, WHITE)
            self.screen.blit(nt, (bx + bw//2 - nt.get_width()//2, by + 38))
            ct   = sfnt.render(f"💰{td['cost']}", True, GOLD)
            self.screen.blit(ct, (bx + bw//2 - ct.get_width()//2, by + 58))
            kt   = sfnt.render(f"[{i+1}]", True, (150,150,170))
            self.screen.blit(kt, (bx + bw - 22, by + 4))

        # Wave button
        if not self.wave_active and self.wave_num < len(ENEMY_WAVES) and self.state == "play":
            wx, wy = 960, SCREEN_H - 100
            pygame.draw.rect(self.screen, GREEN, (wx-45, wy-18, 90, 36), border_radius=12)
            pygame.draw.rect(self.screen, DARK_GREEN, (wx-45, wy-18, 90, 36), 2, border_radius=12)
            wt = fnt.render("▶ GO!", True, WHITE)
            self.screen.blit(wt, (wx - wt.get_width()//2, wy - wt.get_height()//2))

        # Selected tower info
        if self.selected_tower:
            t   = self.selected_tower
            ix  = 10
            iy  = SCREEN_H - 60
            inf = [
                f"{t.name}  Lv.{t.level}",
                f"DMG:{t.damage}  RNG:{t.range}  SPD:{t.fire_rate}",
                f"Kills:{t.kills}  [U]pgrade  [DEL] sell",
            ]
            for j, line in enumerate(inf):
                lt = sfnt.render(line, True, WHITE)
                self.screen.blit(lt, (ix, iy + j * 16))

        # Pause hint
        ph = sfnt.render("[P] Pause  [ESC] Deselect", True, (120,120,140))
        self.screen.blit(ph, (SCREEN_W - ph.get_width() - 10, SCREEN_H - 118))

    def _draw_overlay(self, title, color, sub):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 180))
        self.screen.blit(ov, (0, 0))
        tfnt = pygame.font.SysFont("comicsansms", 52, bold=True)
        sfnt = pygame.font.SysFont("comicsansms", 26)
        t1   = tfnt.render(title, True, color)
        t2   = sfnt.render(sub, True, WHITE)
        self.screen.blit(t1, (SCREEN_W//2 - t1.get_width()//2, SCREEN_H//2 - 60))
        self.screen.blit(t2, (SCREEN_W//2 - t2.get_width()//2, SCREEN_H//2 + 20))

    def _tower_at(self, col, row):
        return any(t.col == col and t.row == row for t in self.towers)

    def handle_event(self, event):
        if self.quiz_popup:
            self.quiz_popup.handle_event(event)
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                self.reset()
            elif event.key == pygame.K_p:
                self.paused = not self.paused
            elif event.key == pygame.K_ESCAPE:
                self.placing = False
                self.selected_tower = None
            elif event.key == pygame.K_1:
                self.selected_type = "math";    self.placing = True; self.selected_tower = None
            elif event.key == pygame.K_2:
                self.selected_type = "letters"; self.placing = True; self.selected_tower = None
            elif event.key == pygame.K_3:
                self.selected_type = "science"; self.placing = True; self.selected_tower = None
            elif event.key == pygame.K_4:
                self.selected_type = "music";   self.placing = True; self.selected_tower = None
            elif event.key == pygame.K_u and self.selected_tower:
                cost = 60 * self.selected_tower.level
                if self.coins >= cost:
                    self.coins -= cost
                    self.selected_tower.upgrade()
                    self.float_texts.append(FloatText(self.selected_tower.x, self.selected_tower.y - 30, "UPGRADED!", GOLD))
            elif event.key == pygame.K_DELETE and self.selected_tower:
                refund = TOWER_TYPES[self.selected_tower.ttype]["cost"] // 2
                self.coins += refund
                self.towers.remove(self.selected_tower)
                self.selected_tower = None

        if event.type == pygame.MOUSEMOTION:
            mx, my = event.pos
            self.hover_cell = (mx // CELL, my // CELL) if my < SCREEN_H - 120 else None

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos

            # Wave button
            if not self.wave_active and self.wave_num < len(ENEMY_WAVES) and self.state == "play":
                if 915 <= mx <= 1005 and SCREEN_H - 118 <= my <= SCREEN_H - 82:
                    self.start_wave()
                    return

            # Tower bar clicks
            for i, ttype in enumerate(TOWER_TYPES):
                bx = 490 + i * 113
                by = SCREEN_H - 112
                if bx <= mx <= bx + 105 and by <= my <= SCREEN_H - 22:
                    self.selected_type  = ttype
                    self.placing        = True
                    self.selected_tower = None
                    return

            # Grid click
            if my < SCREEN_H - 120:
                col, row = mx // CELL, my // CELL

                # Click existing tower
                if self._tower_at(col, row) and not self.placing:
                    for t in self.towers:
                        if t.col == col and t.row == row:
                            self.selected_tower = t
                    return

                # Place tower
                if self.placing and (col, row) not in PATH_SET and not self._tower_at(col, row):
                    cost = TOWER_TYPES[self.selected_type]["cost"]
                    if self.coins >= cost:
                        # Quiz first!
                        def on_correct(c=col, r=row, tt=self.selected_type, co=cost):
                            self.coins -= co
                            self.towers.append(Tower(c, r, tt))
                            self.float_texts.append(FloatText(cell_to_px(c,r)[0], cell_to_px(c,r)[1]-30, "Tower placed!", GREEN))
                        def on_wrong():
                            self.float_texts.append(FloatText(SCREEN_W//2, 300, "Wrong! Tower not placed.", RED))
                        self.quiz_popup = QuizPopup(self.selected_type, on_correct, on_wrong)
                    else:
                        self.float_texts.append(FloatText(mx, my - 20, "Not enough coins!", RED))
                else:
                    self.placing = False
                    self.selected_tower = None

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                self.handle_event(event)
            self.update()
            self.draw()
            self.clock.tick(FPS)

if __name__ == "__main__":
    Game().run()